<template>
    <q-page>

    </q-page>
</template>

<script>
export default {
    name: "editOrganisation"
}
</script>

<style scoped>

</style>