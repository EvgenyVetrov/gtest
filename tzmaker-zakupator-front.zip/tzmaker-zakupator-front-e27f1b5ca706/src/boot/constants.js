export default {
    // типы организаций. Алиасы для переводов
    ORGANISATION_TYPES: {
      1: 'freelancer_type',
      2: 'team_type',
      3: 'entrepreneur_type',
      4: 'organisation_type',
      5: 'head_office_type',
    },
}