// This is just an example,
// so you can safely delete all default props below

export default {
    failed: 'Action failed',
    success: 'Action was successful',
    contacts: 'Contacts',
    terms: 'Terms',
    select_current_organisation_title: 'Select active organisation',
    close: 'close',
    change_active_organisation: 'Change active organisation',
    edit_personal_profile_title: 'Edit personal profile',
    save: 'Save',
    first_name: 'First Name',
    last_name: 'Second Name',
    patronymic: 'Patronymic',

    photo: 'Own photo',
}