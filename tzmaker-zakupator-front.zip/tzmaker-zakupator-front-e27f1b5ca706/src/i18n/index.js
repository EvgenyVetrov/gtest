import enUS from './en-US'
import ru from './ru'
import es from './es'

export default {
    'en-US': enUS,
    'ru': ru,
    'es': es,
}